﻿using System;
using System.Collections.Generic;

namespace tela.MODEL;

public partial class Projeto1
{
    public int Id { get; set; }

    public string? NomeProjeto { get; set; }

    public string? NomeGerente { get; set; }

    public DateTime? DataInicio { get; set; }

    public DateTime? DataFim { get; set; }

    public string? ResumoProjeto { get; set; }

    public string? StatusProjeto { get; set; }
}
