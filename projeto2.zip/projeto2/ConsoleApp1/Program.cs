﻿// See https://aka.ms/new-console-template for more information
using tela.BLL;
using tela.MODEL;

Console.WriteLine("Hello, World!");
Projeto1 p = new Projeto1();
p.NomeProjeto = "Azul";
p.NomeGerente = "sanval";
p.DataInicio = DateTime.Now;
p.DataFim = DateTime.Now;
p.ResumoProjeto = "Bom";
p.StatusProjeto = "Feito";
ProjectRepository.Add(p);
