﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using tela.BLL;
using tela.MODEL;

namespace tela.APP
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime dataInicio = dateTimePicker2.Value;
            DateTime dataFim = dateTimePicker1.Value;
            Projeto1 p = new Projeto1();
            p = ProjectRepository.GetByName(textBox1.Text);
            
            p.NomeProjeto = textBox1.Text;
            p.NomeGerente = textBox2.Text;
            p.DataInicio = dataInicio;
            p.DataFim = dataFim;
            p.ResumoProjeto = textBox3.Text;
            p.StatusProjeto = textBox4.Text;
            ProjectRepository.Update(p);
            MessageBox.Show("Projeto atualizado com sucesso!");
        }
    }
}
