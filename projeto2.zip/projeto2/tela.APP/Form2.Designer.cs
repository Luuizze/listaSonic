﻿namespace tela.APP
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label4 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label5 = new Label();
            dateTimePicker2 = new DateTimePicker();
            label6 = new Label();
            textBox3 = new TextBox();
            label7 = new Label();
            textBox4 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(123, 9);
            label1.Name = "label1";
            label1.Size = new Size(536, 37);
            label1.TabIndex = 0;
            label1.Text = "EDITE O PROJETO BASEADO NO SEU NOME";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(158, 59);
            label2.Name = "label2";
            label2.Size = new Size(98, 15);
            label2.TabIndex = 1;
            label2.Text = "Nome do Projeto";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(158, 77);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(478, 23);
            textBox1.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(158, 112);
            label3.Name = "label3";
            label3.Size = new Size(101, 15);
            label3.TabIndex = 3;
            label3.Text = "Nome do Gerente";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(158, 130);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(478, 23);
            textBox2.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(158, 162);
            label4.Name = "label4";
            label4.Size = new Size(137, 15);
            label4.TabIndex = 5;
            label4.Text = "Data de Inicio do Projeto";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(158, 180);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(478, 23);
            dateTimePicker1.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(158, 215);
            label5.Name = "label5";
            label5.Size = new Size(129, 15);
            label5.TabIndex = 7;
            label5.Text = "Data do Fim do Projeto";
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(158, 233);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(478, 23);
            dateTimePicker2.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(158, 268);
            label6.Name = "label6";
            label6.Size = new Size(108, 15);
            label6.TabIndex = 9;
            label6.Text = "Resumo do Projeto";
            label6.Click += label6_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(158, 286);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(480, 23);
            textBox3.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(158, 316);
            label7.Name = "label7";
            label7.Size = new Size(97, 15);
            label7.TabIndex = 11;
            label7.Text = "Status do Projeto";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(158, 334);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(480, 23);
            textBox4.TabIndex = 12;
            // 
            // button1
            // 
            button1.Location = new Point(299, 363);
            button1.Name = "button1";
            button1.Size = new Size(171, 48);
            button1.TabIndex = 13;
            button1.Text = "Enviar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(textBox4);
            Controls.Add(label7);
            Controls.Add(textBox3);
            Controls.Add(label6);
            Controls.Add(dateTimePicker2);
            Controls.Add(label5);
            Controls.Add(dateTimePicker1);
            Controls.Add(label4);
            Controls.Add(textBox2);
            Controls.Add(label3);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private Label label3;
        private TextBox textBox2;
        private Label label4;
        private DateTimePicker dateTimePicker1;
        private Label label5;
        private DateTimePicker dateTimePicker2;
        private Label label6;
        private TextBox textBox3;
        private Label label7;
        private TextBox textBox4;
        private Button button1;
    }
}