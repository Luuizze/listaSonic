﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using tela.BLL;
using tela.MODEL;

namespace tela.APP
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nomeProjeto = textBox1.Text;
            string nomeGerente = textBox2.Text;
            DateTime dataInicio = dateTimePicker2.Value;
            DateTime dataFim = dateTimePicker1.Value;
            string resumoProjeto = textBox3.Text;
            string statusProjeto = textBox4.Text;

            Projeto1 p = new Projeto1();
           
            p.NomeProjeto = nomeProjeto;
            p.NomeGerente = nomeGerente;
            p.DataInicio = dataInicio;
            p.DataFim = dataFim;
            p.ResumoProjeto = resumoProjeto;
            p.StatusProjeto = statusProjeto;

            ProjectRepository.Add(p);
            MessageBox.Show("Projeto foi adicionado com sucesso!");
        }
    }
}
