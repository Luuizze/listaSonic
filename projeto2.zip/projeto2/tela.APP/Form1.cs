using tela.BLL;
using tela.MODEL;

namespace tela.APP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Projeto1> list = ProjectRepository.GetAll();
            foreach (Projeto1 p in list)
            {
                MessageBox.Show("\n***");
                MessageBox.Show(p.NomeProjeto);
                MessageBox.Show(p.NomeGerente);
                MessageBox.Show(p.DataInicio.ToString());
                MessageBox.Show(p.DataFim.ToString());
                MessageBox.Show(p.ResumoProjeto);
                MessageBox.Show(p.StatusProjeto);
                MessageBox.Show("***\n");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            f.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form4 f = new Form4();
            f.Show();
        }
    }
}