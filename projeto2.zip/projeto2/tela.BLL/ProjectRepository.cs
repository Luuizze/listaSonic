﻿using tela.MODEL;

namespace tela.BLL
{
    public static class ProjectRepository
    {
        public static void Add(Projeto1 _projeto)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposProjeto2TelaDalDatabaseDatabaseMdfContext())
            {
                dbContext.Add(_projeto);
                dbContext.SaveChanges();
            }
        }

        public static Projeto1 GetByName(string nome)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposProjeto2TelaDalDatabaseDatabaseMdfContext())
            {
                var projeto = dbContext.Projeto1s.Single(p => p.NomeProjeto == nome);
                return projeto;
            }
        }


        public static List<Projeto1> GetAll()
        {
            using (var dbContext = new CUsersGuilhermeSourceReposProjeto2TelaDalDatabaseDatabaseMdfContext())
            {
                var projeto = dbContext.Projeto1s.ToList();
                return projeto;
            }
        }

        public static void Update(Projeto1 _projeto)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposProjeto2TelaDalDatabaseDatabaseMdfContext())
            {
                var projeto = dbContext.Projeto1s.Single(p => p.NomeProjeto == _projeto.NomeProjeto);
                projeto.NomeProjeto = _projeto.NomeProjeto;
                projeto.NomeGerente = _projeto.NomeGerente;
                projeto.DataInicio = _projeto.DataInicio;
                projeto.DataFim = _projeto.DataFim;
                projeto.ResumoProjeto = _projeto.ResumoProjeto;
                projeto.StatusProjeto = _projeto.StatusProjeto;
                dbContext.SaveChanges();
            }
        }

        public static void Excluir(Projeto1 _projeto)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposProjeto2TelaDalDatabaseDatabaseMdfContext())
            {
                var projeto = dbContext.Projeto1s.Single(p => p.NomeProjeto == _projeto.NomeProjeto);
                dbContext.Remove(projeto);
                dbContext.SaveChanges();
            }
        }
    }
}