﻿namespace tela.DAL
{
    public class Class1
    {

    }
}