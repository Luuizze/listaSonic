﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace tela.MODEL;

public partial class CUsersGuilhermeSourceReposProjeto2TelaDalDatabaseDatabaseMdfContext : DbContext
{
    public CUsersGuilhermeSourceReposProjeto2TelaDalDatabaseDatabaseMdfContext()
    {
    }

    public CUsersGuilhermeSourceReposProjeto2TelaDalDatabaseDatabaseMdfContext(DbContextOptions<CUsersGuilhermeSourceReposProjeto2TelaDalDatabaseDatabaseMdfContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Projeto1> Projeto1s { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Guilherme\\source\\repos\\projeto2\\tela.DAL\\database\\database.mdf;Integrated Security=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Projeto1>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Projeto1__3214EC07435B58F4");

            entity.ToTable("Projeto1");

            entity.Property(e => e.DataFim)
                .HasColumnType("date")
                .HasColumnName("dataFim");
            entity.Property(e => e.DataInicio)
                .HasColumnType("date")
                .HasColumnName("dataInicio");
            entity.Property(e => e.NomeGerente)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nomeGerente");
            entity.Property(e => e.NomeProjeto)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nomeProjeto");
            entity.Property(e => e.ResumoProjeto)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("resumoProjeto");
            entity.Property(e => e.StatusProjeto)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("statusProjeto");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
